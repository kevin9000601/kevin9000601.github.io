function checkAnswer(selected) {
    const correctAnswer = 'a'; // La respuesta correcta es 'a'
    const feedback = document.getElementById('feedback');
  
    if (selected === correctAnswer) {
      feedback.innerHTML = "¡Correcto! 🐇🐇🐇 La suma de los divisores de 6 es 6 (1, 2, 3).";
      feedback.style.color = 'green';
    } else {
      feedback.innerHTML = "Incorrecto... 😢🐇";
      feedback.style.color = 'red';
    }
  }
  
  function reset() {
    const feedback = document.getElementById('feedback');
    feedback.innerHTML = '';
  }
  