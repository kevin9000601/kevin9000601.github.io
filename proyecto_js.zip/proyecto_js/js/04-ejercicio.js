document.getElementById('form').addEventListener('submit', function(event) {
    event.preventDefault();

    // Obtener valores de los campos
    const producto = document.getElementById('producto').value;
    const cantidad = parseInt(document.getElementById('cantidad').value);
    const precio = parseFloat(document.getElementById('precio').value);

    let total = cantidad * precio;
    let descuento = 0;

    // Aplicar descuentos según el producto
    if (producto === 'televisor' && cantidad >= 2) {
        descuento = total * 0.10; // 10% de descuento
    } else if (producto === 'refrigeradora' && cantidad > 3) {
        descuento = total * 0.15; // 15% de descuento
    }

    // Aplicar descuento adicional si el total antes de descuentos supera los $2000
    if (total - descuento > 2000) {
        descuento += (total - descuento) * 0.05; // 5% de descuento adicional
    }

    const totalFinal = total - descuento;

    // Mostrar el resultado
    document.getElementById('total').textContent = `Total a Pagar: $${totalFinal.toFixed(2)}`;
    document.getElementById('resultado').classList.remove('hidden');
});

// Botón para reiniciar el formulario
document.getElementById('reiniciar').addEventListener('click', function() {
    document.getElementById('form').reset();
    document.getElementById('resultado').classList.add('hidden');
});
