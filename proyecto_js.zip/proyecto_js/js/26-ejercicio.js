function checkAnswer(option) {
    const correctAnswer = 'c';  // La respuesta correcta es la opción 'c' (20 dólares)
    const responseElement = document.getElementById('response');

    // Resalta la opción seleccionada
    const options = document.querySelectorAll('.options li');
    options.forEach(optionElement => {
        optionElement.classList.remove('correct', 'wrong');
        if (optionElement.textContent.trim().charAt(0).toLowerCase() === option) {
            if (option === correctAnswer) {
                optionElement.classList.add('correct');
            } else {
                optionElement.classList.add('wrong');
            }
        }
    });

    // Muestra el mensaje de respuesta
    if (option === correctAnswer) {
        responseElement.textContent = '¡Correcto! El costo total de la entrega es 20 dólares.';
    } else {
        responseElement.textContent = 'Respuesta incorrecta. Intenta nuevamente.';
    }
}

function resetQuiz() {
    const options = document.querySelectorAll('.options li');
    options.forEach(optionElement => {
        optionElement.classList.remove('correct', 'wrong');
    });
    document.getElementById('response').textContent = '';
}
