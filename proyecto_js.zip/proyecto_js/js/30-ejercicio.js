function mostrarRespuesta(opcion) {
    const resultado = document.getElementById("resultado");
    let mensaje;

    switch (opcion) {
        case 1:
            mensaje = "¡Correcto! La respuesta es: 3 4 15, 3 5 33, 3 6 54, 3 7 78.";
            break;
        case 2:
            mensaje = "Incorrecto. Intenta nuevamente.";
            break;
        case 3:
            mensaje = "Incorrecto. Intenta nuevamente.";
            break;
        case 4:
            mensaje = "Incorrecto. Intenta nuevamente.";
            break;
        default:
            mensaje = "Opción no válida.";
    }

    resultado.textContent = mensaje;
}

function resetear() {
    document.getElementById("resultado").textContent = ""; // Borra el mensaje del resultado
}
s