function checkAnswer(selected) {
    const correctAnswer = 'c';
    const feedback = document.getElementById('feedback');
  
    if (selected === correctAnswer) {
      feedback.innerHTML = "¡Correcto! 🐇🐇🐇";
      feedback.style.color = 'green';
    } else {
      feedback.innerHTML = "Incorrecto... 😢🐇";
      feedback.style.color = 'red';
    }
  }
  
  function reset() {
    const feedback = document.getElementById('feedback');
    feedback.innerHTML = '';
  }
  