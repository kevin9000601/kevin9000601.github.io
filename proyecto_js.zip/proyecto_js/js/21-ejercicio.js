function checkAnswer(selected) {
    const resultElement = document.getElementById('result');
    const bunnyElement = document.getElementById('bunny');

    if (selected === 'b') {
        resultElement.textContent = '¡Respuesta correcta!';
        bunnyElement.textContent = '🐰🎉🐰';
        bunnyElement.style.color = 'green';
    } else {
        resultElement.textContent = 'Respuesta incorrecta, intenta de nuevo.';
        bunnyElement.textContent = '🐰😢🐰';
        bunnyElement.style.color = 'red';
    }

    document.getElementById('retryButton').style.display = 'block';
}

function retry() {
    document.getElementById('result').textContent = '';
    document.getElementById('bunny').textContent = '';
    document.getElementById('retryButton').style.display = 'none';
}
