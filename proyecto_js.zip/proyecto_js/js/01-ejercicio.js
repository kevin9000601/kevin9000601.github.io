function mostrarRespuesta(opcion) {
  const resultado = document.getElementById("resultado");
  let mensaje;

  switch (opcion) {
      case 1:
          mensaje = "Incorrecto. El diagrama no presenta solo el número menor.";
          break;
      case 2:
          mensaje = "¡Correcto! El diagrama de flujo presenta el número mayor.";
          break;
      case 3:
          mensaje = "Incorrecto. No presenta ambos números mayor y menor.";
          break;
      case 4:
          mensaje = "Incorrecto. El orden menor y mayor no aplica.";
          break;
      default:
          mensaje = "Opción no válida.";
  }

  resultado.textContent = mensaje;
}

function resetear() {
  document.getElementById("resultado").textContent = ""; // Limpia el resultado
}
