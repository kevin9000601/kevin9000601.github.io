function concatenarNombre() {
    const nombre = document.getElementById("nombre").value.trim();
    const apellido = document.getElementById("apellido").value.trim();
    const resultadoDiv = document.getElementById("resultado");

    if (nombre && apellido) {
        resultadoDiv.textContent = `Resultado: ${apellido}, ${nombre}`;
    } else {
        resultadoDiv.textContent = "Por favor, ingresa ambos campos.";
    }
}
