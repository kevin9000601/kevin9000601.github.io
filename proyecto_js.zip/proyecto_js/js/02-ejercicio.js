function mostrarNumeros() {
    const resultDiv = document.getElementById("result");
    const start = parseInt(document.getElementById("start").value);
    const end = parseInt(document.getElementById("end").value);
  
    if (isNaN(start) || isNaN(end) || start > end) {
      resultDiv.style.display = "block";
      resultDiv.innerHTML = `<p>Por favor, introduce un rango válido.</p>
                             <p>😿🐰 ¡Error en el cálculo! 🐰😿</p>`;
      resultDiv.className = "result incorrect";
      return;
    }
  
    let sumaPares = 0;
    let sumaImpares = 0;
    let divisibles = [];
  
    // Calcular números divisibles y sumas
    for (let i = start; i <= end; i++) {
      if (i % 3 === 0 && i % 7 === 0) {
        divisibles.push(i);
      }
      if (i % 2 === 0) {
        sumaPares += i;
      } else {
        sumaImpares += i;
      }
    }
  
    // Mostrar resultados
    resultDiv.style.display = "block";
    if (divisibles.length > 0) {
      resultDiv.innerHTML = `
        <p>Números divisibles por 3 y 7 en el rango (${start}-${end}): <strong>${divisibles.join(", ")}</strong></p>
        <p>Suma de números pares: <strong>${sumaPares}</strong></p>
        <p>Suma de números impares: <strong>${sumaImpares}</strong></p>
        <p style="font-size: 1.5rem;">🎉🐰 ¡Cálculo exitoso! 🐰🎉</p>
      `;
      resultDiv.className = "result correct";
    } else {
      resultDiv.innerHTML = `
        <p>No se encontraron números divisibles por 3 y 7 en el rango (${start}-${end}).</p>
        <p>😿🐰 ¡Error en el cálculo! 🐰😿</p>
      `;
      resultDiv.className = "result incorrect";
    }
  }
  
  function resetApp() {
    document.getElementById("start").value = "";
    document.getElementById("end").value = "";
    const resultDiv = document.getElementById("result");
    resultDiv.style.display = "none";
    resultDiv.className = "result";
  }
  