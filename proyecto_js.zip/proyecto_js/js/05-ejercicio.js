// Función para contar las palabras en la frase
function contarPalabras() {
    const frase = document.getElementById("frase").value; // Obtener la frase del input
    if (!frase) {
        document.getElementById("resultado").innerHTML = "Por favor, ingresa una frase.";
        return;
    }

    // Separar las palabras de la frase usando el espacio como delimitador
    const palabras = frase.split(" ").filter(palabra => palabra.length > 0);
    const cantidadPalabras = palabras.length;

    // Contar las vocales en cada palabra
    let vocales = 0;
    for (let palabra of palabras) {
        for (let letra of palabra) {
            if (esVocal(letra)) {
                vocales++;
            }
        }
    }

    // Mostrar el resultado
    document.getElementById("resultado").innerHTML = `${cantidadPalabras} palabras tiene la frase.`;
}

// Función para verificar si una letra es una vocal
function esVocal(letra) {
    const vocales = ['a', 'e', 'i', 'o', 'u', 'á', 'é', 'í', 'ó', 'ú'];
    return vocales.includes(letra.toLowerCase());
}

// Función para reiniciar el input y el resultado
function reiniciar() {
    document.getElementById("frase").value = '';
    document.getElementById("resultado").innerHTML = '';
}
