function contarDigitos() {
    const frase = document.getElementById("frase").value.trim();
    const resultadoDiv = document.getElementById("resultado");
    let contadorDigitos = 0;

    // Verificar si la frase contiene dígitos
    if (frase) {
        for (let i = 0; i < frase.length; i++) {
            if (/\d/.test(frase[i])) {  // Verifica si el carácter es un dígito
                contadorDigitos++;
            }
        }
        resultadoDiv.innerHTML = `La frase contiene ${contadorDigitos} dígitos.`;
    } else {
        resultadoDiv.textContent = "Por favor, ingresa una frase.";
    }
}

function resetear() {
    document.getElementById("frase").value = "";  // Limpia el campo de la frase
    document.getElementById("resultado").innerHTML = ""; // Limpia el resultado
}
