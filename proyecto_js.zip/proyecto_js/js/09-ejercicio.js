function checkAnswer(selected) {
    const resultDiv = document.getElementById('result');
    resultDiv.style.display = 'block';
    
    // Respuesta correcta es la opción 'd'
    if (selected === 'd') {
      resultDiv.textContent = "¡Correcto! Los paréntesis se utilizan para agrupar condiciones y establecer la prioridad en la evaluación de la expresión.";
      resultDiv.className = 'result correct';
    } else {
      resultDiv.textContent = "Incorrecto. Los paréntesis no se utilizan para simplificar la expresión ni en bucles. Intenta nuevamente.";
      resultDiv.className = 'result incorrect';
    }
  }
  
  function resetQuiz() {
    const resultDiv = document.getElementById('result');
    resultDiv.style.display = 'none';
  }
  