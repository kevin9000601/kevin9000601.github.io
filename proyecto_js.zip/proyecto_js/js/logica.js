// Ejercicio 1: Recorrer un arreglo de 10 números generados aleatoriamente
function chihiro1() {
    const arreglo = Array.from({ length: 10 }, () => Math.floor(Math.random() * 100));
    document.getElementById('resultado').innerHTML = `<p>Arreglo generado: ${arreglo.join(', ')}</p>`;
}

// Ejercicio 2: Calcular el promedio de cinco calificaciones
function chihiro2() {
    const calificaciones = [
        parseFloat(document.getElementById('calificacion1').value),
        parseFloat(document.getElementById('calificacion2').value),
        parseFloat(document.getElementById('calificacion3').value),
        parseFloat(document.getElementById('calificacion4').value),
        parseFloat(document.getElementById('calificacion5').value)
    ];
    const promedio = calificaciones.reduce((a, b) => a + b, 0) / calificaciones.length;
    document.getElementById('resultado').innerHTML = `<p>Promedio: ${promedio.toFixed(2)}</p>`;
}

// Ejercicio 3: Encontrar el número máximo ingresado por el usuario
function chihiro3() {
    const input = document.getElementById('numeros').value; 
    const numeros = input.split(',').map(num => parseFloat(num.trim())); 

    if (numeros.some(isNaN)) {
        document.getElementById('resultado').innerHTML = `<p>Por favor, ingresa solo números válidos separados por comas.</p>`;
        return;
    }

    const maximo = Math.max(...numeros); 
    document.getElementById('resultado').innerHTML = `
        <p>Números ingresados: ${numeros.join(', ')}</p>
        <p>Número máximo: ${maximo}</p>
    `;
}


// Ejercicio 4: Promedio de números mayores a un valor límite ingresado
function chihiro4() {
    const numerosInput = document.getElementById('numeros').value; 
    const limite = parseFloat(document.getElementById('limite').value); 

    if (isNaN(limite)) {
        document.getElementById('resultado').innerHTML = `<p>Por favor, ingresa un valor límite válido.</p>`;
        return;
    }

    const numeros = numerosInput.split(',').map(num => parseFloat(num.trim()));

    if (numeros.some(isNaN)) {
        document.getElementById('resultado').innerHTML = `<p>Por favor, ingresa solo números válidos separados por comas.</p>`;
        return;
    }

    const mayores = numeros.filter(num => num > limite);

    const promedio = mayores.length ? mayores.reduce((a, b) => a + b, 0) / mayores.length : 0;

    document.getElementById('resultado').innerHTML = `
        <p>Números ingresados: ${numeros.join(', ')}</p>
        <p>Números mayores a ${limite}: ${mayores.join(', ')}</p>
        <p>Promedio de números mayores: ${promedio.toFixed(2)}</p>
    `;
}


// Ejercicio 5: Encontrar el número mínimo ingresado por el usuario
function chihiro5() {
    const numerosInput = document.getElementById('numeros').value;
    const numeros = numerosInput.split(',').map(num => parseFloat(num.trim()));

    if (numeros.some(isNaN)) {
        document.getElementById('resultado').innerHTML = `<p>Por favor, ingresa solo números válidos separados por comas.</p>`;
        return;
    }

    const minimo = Math.min(...numeros);

    document.getElementById('resultado').innerHTML = `
        <p>Números ingresados: ${numeros.join(', ')}</p>
        <p>Número mínimo: ${minimo}</p>
    `;
}


// Ejercicio 6: Calcular el promedio de los números pares ingresados
function chihiro6() {
    const numerosInput = document.getElementById('numeros').value;
    const numeros = numerosInput.split(',').map(num => parseFloat(num.trim())); 

    if (numeros.some(isNaN) || numeros.length !== 10) {
        document.getElementById('resultado').innerHTML = `
            <p>Por favor, ingresa exactamente 10 números válidos separados por comas.</p>`;
        return;
    }

    const pares = numeros.filter(num => num % 2 === 0);

    const promedio = pares.length ? pares.reduce((a, b) => a + b, 0) / pares.length : 0;

    document.getElementById('resultado').innerHTML = `
        <p>Números ingresados: ${numeros.join(', ')}</p>
        <p>Números pares: ${pares.join(', ')}</p>
        <p>Promedio de los números pares: ${promedio.toFixed(2)}</p>
    `;
}


// Ejercicio 7: Suma de dígitos de un número
function chihiro7() {
    const numero = parseInt(document.getElementById('numero').value, 10);
    const suma = numero.toString().split('').reduce((a, b) => a + parseInt(b, 10), 0);
    document.getElementById('resultado').innerHTML = `<p>La suma de los dígitos de ${numero} es: ${suma}</p>`;
}

// Ejercicio 8: Contar y sumar números positivos y negativos ingresados por el usuario
function chihiro8() {
    const numerosInput = document.getElementById('numeros').value;
    const numeros = numerosInput.split(',').map(num => parseFloat(num.trim()));

    if (numeros.some(isNaN) || numeros.length !== 10) {
        document.getElementById('resultado').innerHTML = `
            <p>Por favor, ingresa exactamente 10 números válidos separados por comas.</p>`;
        return;
    }

    const positivos = numeros.filter(num => num > 0);
    const negativos = numeros.filter(num => num < 0);

    const sumaPositivos = positivos.reduce((a, b) => a + b, 0);
    const sumaNegativos = negativos.reduce((a, b) => a + b, 0);

    document.getElementById('resultado').innerHTML = `
        <p>Números ingresados: ${numeros.join(', ')}</p>
        <p>Positivos: ${positivos.length} (Suma: ${sumaPositivos})</p>
        <p>Negativos: ${negativos.length} (Suma: ${sumaNegativos})</p>
    `;
}

