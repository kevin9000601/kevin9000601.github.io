function invertirFrase() {
    const frase = document.getElementById("frase").value.trim();
    const resultadoDiv = document.getElementById("resultado");

    if (frase) {
        // Invertir la frase
        const fraseInvertida = frase.split('').reverse().join('');
        resultadoDiv.innerHTML = `Frase invertida: ${fraseInvertida}`;
    } else {
        resultadoDiv.textContent = "Por favor, ingresa una frase.";
    }
}

function resetear() {
    document.getElementById("frase").value = "";  // Limpia el campo de la frase
    document.getElementById("resultado").innerHTML = ""; // Limpia el resultado
}
