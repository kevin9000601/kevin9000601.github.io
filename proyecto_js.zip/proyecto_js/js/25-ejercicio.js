// Función que calcula la suma de los números pares hasta n (en este caso 10)
function sumaPares(n) {
    let suma = 0;
    for (let i = 0; i <= n; i++) {
      if (i % 2 === 0) {
        suma += i;
      }
    }
    return suma;
  }
  
  // Verificar la respuesta seleccionada
  function checkAnswer(selected) {
    const correctAnswer = 'a'; // La respuesta correcta es 'a'
    const feedback = document.getElementById('feedback');
  
    if (selected === correctAnswer) {
      feedback.innerHTML = "¡Correcto! 🐇🐇🐇 La suma de los números pares hasta 10 es 30.";
      feedback.style.color = 'green';
    } else {
      feedback.innerHTML = "Incorrecto... 😢🐇";
      feedback.style.color = 'red';
    }
  }
  
  // Resetear el feedback al hacer clic en "Intentar de nuevo"
  function reset() {
    const feedback = document.getElementById('feedback');
    feedback.innerHTML = '';
  }
  