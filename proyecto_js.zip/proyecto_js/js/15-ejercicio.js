// Verificar la respuesta seleccionada
function verificarRespuesta(opcion) {
    const resultadoDiv = document.getElementById("resultado");
  
    if (opcion === "d") {
      // Respuesta correcta
      resultadoDiv.innerHTML = "🎈🎉 ¡Correcto! 🎉🎈 <br> 🥳 La respuesta es 1A, 2B, 3D, 4C.";
      resultadoDiv.className = "result correct";
    } else {
      // Respuesta incorrecta
      resultadoDiv.innerHTML = "❌ Incorrecto. Por favor, inténtalo de nuevo.";
      resultadoDiv.className = "result incorrect";
    }
  }
  
  // Reiniciar el ejercicio
  function reiniciar() {
    const resultadoDiv = document.getElementById("resultado");
    resultadoDiv.innerHTML = "";
    resultadoDiv.className = "result";
  }
  