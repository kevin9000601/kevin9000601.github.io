// Función para verificar la respuesta seleccionada
function verificarRespuesta(opcion) {
    const resultadoDiv = document.getElementById("resultado");
  
    if (opcion === "b") {
      // Respuesta correcta
      resultadoDiv.innerHTML = "🐇😊 ¡Correcto! El resultado de 4 x 5 es 20.";
      resultadoDiv.className = "result correct";
    } else {
      // Respuesta incorrecta
      resultadoDiv.innerHTML = "🐇😢 Incorrecto. Inténtalo de nuevo.";
      resultadoDiv.className = "result incorrect";
    }
  }
  