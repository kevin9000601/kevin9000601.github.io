function contarLetras() {
    const palabra = document.getElementById("palabra").value.trim().toLowerCase();
    const resultadoDiv = document.getElementById("resultado");
    let contadorLetras = 0;

    // Definir las letras del alfabeto
    const alfabeto = 'abcdefghijklmnopqrstuvwxyzáéíóú';

    // Verificar si la palabra contiene letras del alfabeto
    if (palabra) {
        for (let i = 0; i < palabra.length; i++) {
            if (alfabeto.includes(palabra[i])) {
                contadorLetras++;
            }
        }
        resultadoDiv.innerHTML = `La palabra "${palabra}" tiene ${contadorLetras} letras del alfabeto.`;
    } else {
        resultadoDiv.textContent = "Por favor, ingresa una palabra.";
    }
}

function resetear() {
    document.getElementById("palabra").value = "";  // Limpia el campo de la palabra
    document.getElementById("resultado").innerHTML = ""; // Limpia el resultado
}
