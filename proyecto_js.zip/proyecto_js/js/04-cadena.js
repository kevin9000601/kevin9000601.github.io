function mostrarCodigosASCII() {
    const frase = document.getElementById("frase").value.trim();
    const resultadoDiv = document.getElementById("resultado");

    if (frase) {
        // Creamos un array con los códigos ASCII de cada carácter
        let resultado = '';
        for (let i = 0; i < frase.length; i++) {
            const codigoAscii = frase.charCodeAt(i); // Usamos charCodeAt para obtener el código ASCII
            resultado += `Carácter: "${frase[i]}" - Código ASCII: ${codigoAscii}<br>`;
        }
        resultadoDiv.innerHTML = resultado;
    } else {
        resultadoDiv.textContent = "Por favor, ingresa una frase.";
    }
}

function resetear() {
    document.getElementById("frase").value = "";  // Limpia el campo de la frase
    document.getElementById("resultado").innerHTML = ""; // Limpia el resultado
}
