function calcularTotal() {
  // Obtener los valores ingresados por el usuario
  const precio = parseFloat(document.getElementById("precio").value);
  const cantidad = parseInt(document.getElementById("cantidad").value);
  const aplicarIva = document.getElementById("iva").checked;
  const resultado = document.getElementById("resultado");
  // Calcular subtotal
  let subtotal = precio * cantidad;
  // Aplicar descuento si la cantidad es mayor a 10
  let descuento = 0 
  if (cantidad > 10){
    descuento=subtotal * 0.10
  }
  // Calcular IVA si el checkbox está seleccionado
  let  iva = 0
  if (aplicarIva==true){
    iva = (subtotal - descuento) * 0.15 
  } 
  // Calcular total
  const total = subtotal - descuento + iva;
  // Mostrar resultados en el área de texto
  resultado.innerHTML = `
                Subtotal: ${subtotal.toFixed(2)} USD
                Descuento: ${descuento.toFixed(2)} USD
                IVA: ${iva.toFixed(2)} USD
                Total a pagar: ${total.toFixed(2)} USD
            `;
}

function verificarRespuesta() {
  // Obtener la opción seleccionada por el usuario
  const respuestaSeleccionada = document.querySelector('input[name="respuesta"]:checked');
  const resultadoDiv = document.getElementById('resultado');

  // Verificar si se seleccionó una respuesta
  if (!respuestaSeleccionada) {
    resultadoDiv.innerHTML = '<p class="respuesta-incorrecta">🙄 ¡Selecciona una opción antes de continuar! 🙄</p>';
    return;
  }

  // La línea correcta que tiene un error es la línea 3
  const respuestaCorrecta = '3';

  // Comprobar si la respuesta seleccionada es correcta
  if (respuestaSeleccionada.value === respuestaCorrecta) {
    resultadoDiv.innerHTML = '<p class="respuesta-correcta">🎉 ¡Correcto! La línea 3 tiene un error 🎉</p>';
  } else {
    resultadoDiv.innerHTML = '<p class="respuesta-incorrecta">❌ Incorrecto. ¡Vuelve a intentarlo! ❌</p>';
  }
}

//Promedio de numeros
function calcularPromedio() {
  // Obtener los números ingresados
  const input = document.getElementById("numbersInput").value;

  // Procesar los números
  let numeros = [];
  let numeroActual = '';
  for (let i = 0; i < input.length; i++) {
      const char = input[i];
      if (char === ',') {
          if (numeroActual.trim() === '') {
              document.getElementById("resultadoArea").value = "Error: Entrada inválida.";
              return;
          }
          numeros.push(parseFloat(numeroActual.trim()));
          numeroActual = '';
      } else {
          numeroActual += char;
      }
  }

  // Procesar el último número
  if (numeroActual.trim() !== '') {
      numeros.push(parseFloat(numeroActual.trim()));
  }

  // Validar si el arreglo está vacío
  if (numeros.length === 0) {
      document.getElementById("resultadoArea").value = "No se ingresaron números.";
      return;
  }

  // Calcular el promedio
  let suma = 0;
  for (let i = 0; i < numeros.length; i++) {
      suma += numeros[i];
  }
  const promedio = suma / numeros.length;

  // Mostrar el resultado
  document.getElementById("resultadoArea").value = `${promedio}`;
}
//exercive6
function verificarRespuesta() {
// Obtener el valor de la respuesta seleccionada
  const opciones = document.getElementsByName('respuesta');
 let respuestaSeleccionada = null;
  for (const opcion of opciones) {
    if (opcion.checked) {
      respuestaSeleccionada = opcion.value;
    break;
      }
    }

// Obtener el elemento donde se mostrará el resultado
  const resultadoDiv = document.getElementById('resultado');

// Verificar la respuesta seleccionada
if (respuestaSeleccionada === "3") { // Respuesta correcta es "c" (valor 3)
   resultadoDiv.textContent = "¡Correcto! Has seleccionado la respuesta correcta.";
   resultadoDiv.className = "text-success"; // Aplicar estilo verde
   } else {
     resultadoDiv.textContent = "Incorrecto, inténtalo de nuevo.";
    resultadoDiv.className = "text-danger"; // Aplicar estilo rojo
   }
}
