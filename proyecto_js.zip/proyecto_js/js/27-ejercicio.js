function checkAnswer(option) {
    const correctAnswer = 'b';  // La respuesta correcta es la opción 'b'
    const responseElement = document.getElementById('response');

    // Resalta la opción seleccionada
    const options = document.querySelectorAll('.options li');
    options.forEach(optionElement => {
        optionElement.classList.remove('correct', 'wrong');
        if (optionElement.textContent.trim().charAt(0).toLowerCase() === option) {
            if (option === correctAnswer) {
                optionElement.classList.add('correct');
            } else {
                optionElement.classList.add('wrong');
            }
        }
    });

    // Muestra el mensaje de respuesta
    if (option === correctAnswer) {
        responseElement.textContent = '¡Correcto! La complejidad algorítmica mide los recursos computacionales (tiempo y espacio) que un algoritmo necesita para ejecutarse.';
    } else {
        responseElement.textContent = 'Respuesta incorrecta. Intenta nuevamente.';
    }
}

function resetQuiz() {
    const options = document.querySelectorAll('.options li');
    options.forEach(optionElement => {
        optionElement.classList.remove('correct', 'wrong');
    });
    document.getElementById('response').textContent = '';
}

