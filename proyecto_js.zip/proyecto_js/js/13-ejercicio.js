// Función para verificar la respuesta
function verificarRespuesta(opcion) {
    const resultadoDiv = document.getElementById("resultado");
  
    if (opcion === "a") {
      // Respuesta correcta
      resultadoDiv.innerHTML = "🐇😊 ¡Correcto! El resultado es 9765625.";
      resultadoDiv.className = "result correct";
    } else {
      // Respuesta incorrecta
      resultadoDiv.innerHTML = "🐇😢 Incorrecto. Inténtalo de nuevo.";
      resultadoDiv.className = "result incorrect";
    }
  }
  
  // Función para reiniciar el ejercicio
  function reiniciar() {
    const resultadoDiv = document.getElementById("resultado");
    resultadoDiv.innerHTML = "";
    resultadoDiv.className = "result";
  }
  