function compararFrases() {
    const frase1 = document.getElementById("frase1").value.trim();
    const frase2 = document.getElementById("frase2").value.trim();
    const resultadoDiv = document.getElementById("resultado");

    if (frase1 && frase2) {
        if (frase1 === frase2) {
            resultadoDiv.textContent = "Las frases son iguales.";
        } else if (frase1 > frase2) {
            resultadoDiv.textContent = "La primera frase es mayor que la segunda.";
        } else {
            resultadoDiv.textContent = "La primera frase es menor que la segunda.";
        }
    } else {
        resultadoDiv.textContent = "Por favor, ingresa ambas frases.";
    }
}

function resetear() {
    document.getElementById("frase1").value = "";  // Limpia la primera frase
    document.getElementById("frase2").value = "";  // Limpia la segunda frase
    document.getElementById("resultado").textContent = ""; // Limpia el resultado
}
