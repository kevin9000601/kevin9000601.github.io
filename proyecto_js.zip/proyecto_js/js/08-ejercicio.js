function checkAnswer(selected) {
    const resultDiv = document.getElementById('result');
    resultDiv.style.display = 'block';
    
    if (selected === 'b') {
      resultDiv.textContent = "¡Correcto! La fase de 'Proceso' se encarga de realizar cálculos y transformar datos para obtener el resultado.";
      resultDiv.className = 'result correct';
    } else {
      resultDiv.textContent = "Incorrecto. La fase de 'Proceso' no corresponde a esa descripción. Intenta nuevamente.";
      resultDiv.className = 'result incorrect';
    }
  }
  
  function resetQuiz() {
    const resultDiv = document.getElementById('result');
    resultDiv.style.display = 'none';
  }
  