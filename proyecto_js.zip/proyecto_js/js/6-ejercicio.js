function contarVocales() {
    const palabra = document.getElementById("palabra").value.trim().toLowerCase();
    const resultadoDiv = document.getElementById("resultado");
    let contadorVocales = 0;

    // Verificar si la palabra contiene vocales
    if (palabra) {
        for (let i = 0; i < palabra.length; i++) {
            if ('aeiouáéíóú'.includes(palabra[i])) {
                contadorVocales++;
            }
        }
        resultadoDiv.innerHTML = `La palabra "${palabra}" tiene ${contadorVocales} vocales.`;
    } else {
        resultadoDiv.textContent = "Por favor, ingresa una palabra.";
    }
}

function resetear() {
    document.getElementById("palabra").value = "";  // Limpia el campo de la palabra
    document.getElementById("resultado").innerHTML = ""; // Limpia el resultado
}
