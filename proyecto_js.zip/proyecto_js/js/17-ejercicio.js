function calcularPromedio() {
    // Obtener los números ingresados por el usuario
    const input = document.getElementById("numeros").value;
    const numeros = input.split(",").map((num) => parseInt(num.trim()));
  
    // Validar que el usuario ingresó 10 números
    if (numeros.length !== 10 || numeros.some(isNaN)) {
      document.getElementById("resultado").innerHTML = `
        <p style="color: red;">🐇😭 Por favor, introduce exactamente 10 números separados por comas.</p>
      `;
      return;
    }
  
    // Filtrar los números pares
    const pares = numeros.filter((num) => num % 2 === 0);
  
    // Calcular el promedio de los números pares
    const sumaPares = pares.reduce((acc, num) => acc + num, 0);
    const promedioPares = pares.length > 0 ? sumaPares / pares.length : 0;
  
    // Mostrar el resultado con emojis de festejo si hay pares
    if (pares.length > 0) {
      document.getElementById("resultado").innerHTML = `
        <p><strong>Números pares:</strong> ${pares.join(", ")}</p>
        <p><strong>Promedio de los pares:</strong> ${promedioPares.toFixed(2)}</p>
        <p style="color: green;">🎉🐇🎉 ¡Cálculo correcto! ¡Bien hecho!</p>
      `;
    } else {
      // Mostrar conejo triste si no hay pares
      document.getElementById("resultado").innerHTML = `
        <p style="color: red;">🐇😭 No hay números pares en el arreglo. Intenta de nuevo.</p>
      `;
    }
  }
  
  function reiniciar() {
    // Limpiar el campo de entrada y el resultado
    document.getElementById("numeros").value = "";
    document.getElementById("resultado").innerHTML = "";
  }
  