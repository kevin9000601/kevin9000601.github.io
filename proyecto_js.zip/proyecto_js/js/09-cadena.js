function contarSignos() {
    const palabra = document.getElementById("palabra").value.trim();
    const resultadoDiv = document.getElementById("resultado");
    let contadorSignos = 0;

    // Definir los signos de puntuación comunes
    const signosPuntuacion = ['.', ',', ';', ':', '!', '?', '(', ')', '[', ']', '{', '}', '"', "'", '-', '_', '—'];

    // Verificar si la palabra contiene signos de puntuación
    if (palabra) {
        for (let i = 0; i < palabra.length; i++) {
            if (signosPuntuacion.includes(palabra[i])) {  // Verifica si el carácter es un signo de puntuación
                contadorSignos++;
            }
        }
        resultadoDiv.innerHTML = `La palabra contiene ${contadorSignos} signos de puntuación.`;
    } else {
        resultadoDiv.textContent = "Por favor, ingresa una palabra.";
    }
}

function resetear() {
    document.getElementById("palabra").value = "";  // Limpia el campo de la palabra
    document.getElementById("resultado").innerHTML = ""; // Limpia el resultado
}
