function separarPalabra() {
    const palabra = document.getElementById("palabra").value.trim();
    const resultadoDiv = document.getElementById("resultado");

    if (palabra) {
        const palabraSeparada = palabra.split('').join(' ');
        resultadoDiv.textContent = `Palabra separada: ${palabraSeparada}`;
    } else {
        resultadoDiv.textContent = "Por favor, ingresa una palabra.";
    }
}

function resetear() {
    document.getElementById("palabra").value = ""; 
    document.getElementById("resultado").textContent = "";
}
