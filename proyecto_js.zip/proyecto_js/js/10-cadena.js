function contarPalabras() {
    const frase = document.getElementById("frase").value.trim();
    const resultadoDiv = document.getElementById("resultado");

    // Verificar si la frase contiene palabras
    if (frase) {
        // Contar las palabras separadas por espacios
        const palabras = frase.split(/\s+/);
        const cantidadPalabras = palabras.length;

        resultadoDiv.innerHTML = `La frase contiene ${cantidadPalabras} palabras.`;
    } else {
        resultadoDiv.textContent = "Por favor, ingresa una frase.";
    }
}

function resetear() {
    document.getElementById("frase").value = "";  // Limpia el campo de la frase
    document.getElementById("resultado").innerHTML = ""; // Limpia el resultado
}
