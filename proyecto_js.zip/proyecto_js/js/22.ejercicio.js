function checkAnswer() {
    const options = document.getElementsByName("answer");
    let selectedAnswer = null;
    for (const option of options) {
        if (option.checked) {
            selectedAnswer = option.value;
            break;
        }
    }

    const resultDiv = document.getElementById("result");
    if (selectedAnswer === "c") {
        resultDiv.innerHTML = "<p>🎉 ¡Respuesta correcta! 🐰</p>";
    } else {
        resultDiv.innerHTML = "<p>😞 Respuesta incorrecta. 🐰</p>";
    }
}

function reset() {
    const options = document.getElementsByName("answer");
    for (const option of options) {
        option.checked = false;
    }
    document.getElementById("result").innerHTML = "";
}
