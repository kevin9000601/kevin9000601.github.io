// Respuesta correcta
const respuestaCorrecta = "3,5";

function verificarRespuesta() {
  // Obtener la respuesta seleccionada
  const opciones = document.getElementsByName("answer");
  let seleccion = "";

  for (let opcion of opciones) {
    if (opcion.checked) {
      seleccion = opcion.value;
      break;
    }
  }

  // Verificar si la respuesta es correcta
  const resultadoDiv = document.getElementById("resultado");

  if (seleccion === respuestaCorrecta) {
    resultadoDiv.innerHTML = `
      <p style="color: green;">🎉🐇🎉 ¡Correcto! La línea 3 tiene el mensaje incorrecto y la línea 5 está mal colocada.</p>
    `;
  } else {
    resultadoDiv.innerHTML = `
      <p style="color: red;">🐇😭 Respuesta incorrecta. Intenta nuevamente.</p>
    `;
  }
}

function reiniciar() {
  // Limpiar las opciones seleccionadas y el resultado
  const opciones = document.getElementsByName("answer");
  for (let opcion of opciones) {
    opcion.checked = false;
  }
  document.getElementById("resultado").innerHTML = "";
}
