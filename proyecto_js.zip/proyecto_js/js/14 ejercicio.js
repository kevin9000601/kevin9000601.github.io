// Función para verificar la respuesta
function verificarRespuesta(opcion) {
    const resultadoDiv = document.getElementById("resultado");
  
    if (opcion === "b") {
      // Respuesta correcta
      resultadoDiv.innerHTML = "🐇😊 ¡Correcto! El resultado de sumaImpares(5) es 15.";
      resultadoDiv.className = "result correct";
    } else {
      // Respuesta incorrecta
      resultadoDiv.innerHTML = "🐇😢 Incorrecto. Inténtalo de nuevo.";
      resultadoDiv.className = "result incorrect";
    }
  }
  
  // Función para reiniciar el ejercicio
  function reiniciar() {
    const resultadoDiv = document.getElementById("resultado");
    resultadoDiv.innerHTML = "";
    resultadoDiv.className = "result";
  }
  