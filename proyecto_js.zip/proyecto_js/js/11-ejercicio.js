function checkAnswer(selected) {
    const resultDiv = document.getElementById('result');
    resultDiv.style.display = 'block';
    
    // Respuesta correcta es la opción 'b'
    if (selected === 'b') {
      resultDiv.innerHTML = "¡Correcto! La función Resta(10, 4) devuelve 6. 🐰🎉";
      resultDiv.className = 'result correct';
    } else {
      resultDiv.innerHTML = "Incorrecto. La respuesta correcta es b) 6. 😿🐰";
      resultDiv.className = 'result incorrect';
    }
  }
  
  function resetQuiz() {
    const resultDiv = document.getElementById('result');
    resultDiv.style.display = 'none';
  }
  
