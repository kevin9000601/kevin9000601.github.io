
function calcularFactura() {
    const subtotal = parseFloat(document.getElementById("subtotal").value);
    const dia = document.getElementById("dia").value;
    const personas = parseInt(document.getElementById("personas").value);
    const pagoConTarjeta = document.getElementById("tarjeta").checked;
  
    const resultDiv = document.getElementById("result");
    resultDiv.style.display = "block";
  
    // Validar entrada
    if (isNaN(subtotal) || subtotal <= 0 || isNaN(personas) || personas <= 0) {
      resultDiv.innerHTML = "Por favor, introduce valores válidos. 😿🐰";
      resultDiv.className = "result incorrect";
      return;
    }
  
    // Inicializar descuentos y recargos
    let descuento = 0;
    let recargo = 0;
  
    // Descuento del 15% para lunes o miércoles con más de 4 personas
    if ((dia === "lunes" || dia === "miércoles") && personas > 4) {
      descuento = subtotal * 0.15;
    }
  
    // Recargo del 10% para sábado o domingo
    if (dia === "sábado" || dia === "domingo") {
      recargo = subtotal * 0.10;
    }
  
    // Comisión del 5% si se paga con tarjeta
    if (pagoConTarjeta) {
      recargo += subtotal * 0.05;
    }
  
    // Calcular el total
    const total = subtotal - descuento + recargo;
  
    // Mostrar resultado
    if (total > 0) {
      resultDiv.innerHTML = 
        `El total a pagar es: $${total.toFixed(2)} 🐰🎉 (Descuento: $${descuento.toFixed(2)}, Recargo: $${recargo.toFixed(2)})`;
      resultDiv.className = "result correct";
    } else {
      resultDiv.innerHTML = "Algo salió mal, verifica los datos. 😿🐰";
      resultDiv.className = "result incorrect";
    }
  }
  
  function resetApp() {
    document.getElementById("subtotal").value = "";
    document.getElementById("dia").value = "lunes";
    document.getElementById("personas").value = "";
    document.getElementById("tarjeta").checked = false;
  
    const resultDiv = document.getElementById("result");
    resultDiv.style.display = "non