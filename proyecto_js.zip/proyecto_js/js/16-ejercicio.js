function calcularSuma() {
    // Obtener el número ingresado por el usuario
    const numero = document.getElementById("numero").value;
  
    // Validar que el usuario ingresó un número
    if (numero === "" || isNaN(numero) || parseInt(numero) < 0) {
      document.getElementById("resultado").innerHTML = `
        <p style="color: red;">🐇😭 Por favor, introduce un número válido y positivo.</p>
      `;
      return;
    }
  
    // Convertir el número en un arreglo de dígitos
    const digitos = [];
    for (let i = 0; i < numero.length; i++) {
      digitos.push(parseInt(numero[i]));
    }
  
    // Calcular la suma de los dígitos
    let suma = 0;
    for (let i = 0; i < digitos.length; i++) {
      suma += digitos[i];
    }
  
    // Mostrar el resultado con emojis de festejo
    document.getElementById("resultado").innerHTML = `
      <p><strong>Dígitos:</strong> ${digitos.join(", ")}</p>
      <p><strong>Suma de los dígitos:</strong> ${suma}</p>
      <p style="color: green;">🎉🐇🎉 ¡Cálculo correcto! ¡Bien hecho!</p>
    `;
  }
  
  function reiniciar() {
    // Limpiar el campo de entrada y el resultado
    document.getElementById("numero").value = "";
    document.getElementById("resultado").innerHTML = "";
  }
  