function checkAnswer(selected) {
    const resultDiv = document.getElementById('result');
    resultDiv.style.display = 'block';
    
    if (selected === 'c') {
      resultDiv.textContent = "¡Correcto! Una representación simplificada y estructurada de un algoritmo que utiliza un lenguaje intermedio entre el lenguaje humano y el lenguaje de programación.";
      resultDiv.className = 'result correct';
    } else {
      resultDiv.textContent = "Incorrecto. Intenta de nuevo.";
      resultDiv.className = 'result incorrect';
    }
  }
  
  function resetQuiz() {
    const resultDiv = document.getElementById('result');
    resultDiv.style.display = 'none';
  }
  