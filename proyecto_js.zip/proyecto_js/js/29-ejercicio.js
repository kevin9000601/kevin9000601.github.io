function verificarPrimo(num) {
    if (num <= 1) return false;
    for (let i = 2; i < num; i++) {
        if (num % i === 0) return false;
    }
    return true;
}

function verificar() {
    const numero = parseInt(document.getElementById("numero").value);
    const resultado = document.getElementById("resultado");

    if (isNaN(numero)) {
        resultado.textContent = "Por favor, ingresa un número válido.";
        return;
    }

    const esPrimo = verificarPrimo(numero);
    resultado.textContent = esPrimo
        ? `${numero} es un número primo.`
        : `${numero} no es un número primo.`;
}

function resetear() {
    document.getElementById("numero").value = "";
    document.getElementById("resultado").textContent = "";
}


