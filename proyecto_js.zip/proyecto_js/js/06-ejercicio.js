function verificarRespuesta() {
    // Obtener las opciones seleccionadas
    var respuestaA = document.getElementById("a").checked;
    var respuestaB = document.getElementById("b").checked;
    var respuestaC = document.getElementById("c").checked;
    var respuestaD = document.getElementById("d").checked;

    var resultado = document.getElementById("resultado");

    // Verificar si la opción correcta (b) está seleccionada
    if (respuestaB && !respuestaA && !respuestaC && !respuestaD) {
        resultado.innerHTML = "¡Correcto! La respuesta es: b. Es cuando una condición condicional se encuentra dentro de otra condición condicional.";
        resultado.style.color = "green";
    } else {
        resultado.innerHTML = "Incorrecto. Intenta nuevamente.";
        resultado.style.color = "red";
    }
}

function reiniciar() {
    // Reiniciar las opciones seleccionadas
    var opciones = document.getElementsByName("opcion");
    for (var i = 0; i < opciones.length; i++) {
        opciones[i].checked = false;
    }
    // Limpiar el resultado
    document.getElementById("resultado").innerHTML = "";
}
