function checkAnswer(option) {
    const correctAnswer = 'b';  // La respuesta correcta es la opción 'b'
    const responseElement = document.getElementById('response');

    // Resalta la opción seleccionada
    const options = document.querySelectorAll('.options li');
    options.forEach(optionElement => {
        optionElement.classList.remove('correct', 'wrong');
        if (optionElement.textContent.trim().charAt(0).toLowerCase() === option) {
            if (option === correctAnswer) {
                optionElement.classList.add('correct');
            } else {
                optionElement.classList.add('wrong');
            }
        }
    });

    // Muestra el mensaje de respuesta
    if (option === correctAnswer) {
        responseElement.textContent = '¡Correcto! Los algoritmos no requieren múltiples lenguajes de programación para su implementación.';
        responseElement.style.color = '#4CAF50';  // Verde para respuesta correcta
    } else {
        responseElement.textContent = 'Respuesta incorrecta. Intenta nuevamente.';
        responseElement.style.color = '#f44336';  // Rojo para respuesta incorrecta
    }
}

function resetQuiz() {
    const options = document.querySelectorAll('.options li');
    options.forEach(optionElement => {
        optionElement.classList.remove('correct', 'wrong');
    });
    document.getElementById('response').textContent = '';
}
