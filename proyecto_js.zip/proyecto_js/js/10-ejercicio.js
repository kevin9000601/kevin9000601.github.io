function checkAnswer(selected) {
    const resultDiv = document.getElementById('result');
    resultDiv.style.display = 'block';
    
    // Respuesta correcta es la opción 'b'
    if (selected === 'b') {
      resultDiv.textContent = "¡Correcto! El tiempo total será de 45 minutos (15 minutos por ubicación).";
      resultDiv.className = 'result correct';
    } else {
      resultDiv.textContent = "Incorrecto. El tiempo total es de 45 minutos. Intenta nuevamente.";
      resultDiv.className = 'result incorrect';
    }
  }
  
  function resetQuiz() {
    const resultDiv = document.getElementById('result');
    resultDiv.style.display = 'none';
  }
  